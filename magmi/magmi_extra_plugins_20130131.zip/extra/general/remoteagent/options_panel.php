<div class="plugin_description">
This plugins enable remote operations of magmi by deploying an agent on a target system
The agent will be used if magento base directory is remote ftp
</div>
<ul class="formline">
<li class="label">
 	<span>HTTP Url for magento base dir</span>
</li>
	<li class="value">
		<input type="text" name="MRAGENT:baseurl" value="<?php echo $this->getParam("MRAGENT:baseurl","")?>">
	</li>
	
</ul>