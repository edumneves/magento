<div class="plugin_description">
This plugin let you import custom options for products
</div>
